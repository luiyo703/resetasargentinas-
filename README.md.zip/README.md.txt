# resetasargentinas-<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Recetas Argentinas - Tienda</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f5f5f5; }
    header { background-color: #8B0000; color: white; padding: 1rem; text-align: center; }
    nav { display: flex; justify-content: center; gap: 2rem; background: #e0e0e0; padding: 1rem; }
    nav a { text-decoration: none; color: #333; font-weight: bold; }
    section { padding: 2rem; }
    .product { background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .product img { max-width: 100%; border-radius: 6px; margin-bottom: 1rem; }
    .cart { background: #fff8dc; padding: 1rem; border-radius: 8px; }
    .button { background: #8B0000; color: white; padding: 0.5rem 1rem; border: none; border-radius: 4px; cursor: pointer; }
    footer { background: #333; color: white; text-align: center; padding: 1rem; margin-top: 2rem; }
  </style>
</head>
<body>
  <header>
    <h1>Recetas Típicas y Tradicionales Argentinas</h1>
  </header>
  <nav>
    <a href="#recetas">Recetas</a>
    <a href="#bebidas">Bebidas</a>
    <a href="#carrito">Carrito</a>
    <a href="#pago">Pagar</a>
  </nav>

  <section id="recetas">
    <h2>Recetas</h2>
    <div class="product">
      <img src="https://cdn.pixabay.com/photo/2020/07/22/11/14/empanadas-5428917_1280.jpg" alt="Empanadas Salteñas">
      <h3>Empanadas Salteñas</h3>
      <p>Receta detallada paso a paso + ingredientes.</p>
      <p><strong>Precio:</strong> $1000 ARS</p>
      <button class="button" onclick="addToCart('Empanadas Salteñas', 1000)">Agregar al carrito</button>
    </div>
    <div class="product">
      <img src="https://cdn.pixabay.com/photo/2022/05/25/16/31/locro-7220792_1280.jpg" alt="Locro">
      <h3>Locro</h3>
      <p>Guía completa para preparar este plato tradicional.</p>
      <p><strong>Precio:</strong> $1200 ARS</p>
      <button class="button" onclick="addToCart('Locro', 1200)">Agregar al carrito</button>
    </div>
  </section>

  <section id="bebidas">
    <h2>Bebidas</h2>
    <div class="product">
      <img src="https://cdn.pixabay.com/photo/2021/06/15/20/17/fernet-6339476_1280.jpg" alt="Fernet con Coca">
      <h3>Fernet con Coca</h3>
      <p>Preparación y proporciones ideales.</p>
      <p><strong>Precio:</strong> $800 ARS</p>
      <button class="button" onclick="addToCart('Fernet con Coca', 800)">Agregar al carrito</button>
    </div>
    <div class="product">
      <img src="https://cdn.pixabay.com/photo/2022/05/16/16/24/mate-7200468_1280.jpg" alt="Mate Argentino">
      <h3>Mate Argentino</h3>
      <p>La ceremonia del mate: tipos, formas y secretos.</p>
      <p><strong>Precio:</strong> $600 ARS</p>
      <button class="button" onclick="addToCart('Mate Argentino', 600)">Agregar al carrito</button>
    </div>
  </section>

  <section id="carrito">
    <h2>Carrito</h2>
    <div class="cart" id="cart">
      <p>No hay productos en el carrito.</p>
    </div>
  </section>

  <section id="pago">
    <h2>Formas de Pago</h2>
    <ul>
      <li>Transferencia bancaria</li>
      <li>MercadoPago</li>
      <li>Tarjeta de crédito/débito (vía PayPal o Stripe)</li>
      <li>Efectivo contra entrega (opcional)</li>
    </ul>
    <button class="button" onclick="checkout()">Ir a pagar</button>
  </section>

  <footer>
    <p>&copy; 2025 Recetas Argentinas. Todos los derechos reservados.</p>
  </footer>

  <script>
    const cart = [];

    function addToCart(product, price) {
      cart.push({ product, price });
      renderCart();
    }

    function renderCart() {
      const cartDiv = document.getElementById('cart');
      if (cart.length === 0) {
        cartDiv.innerHTML = '<p>No hay productos en el carrito.</p>';
        return;
      }
      let html = '<ul>';
      let total = 0;
      cart.forEach(item => {
        html += `<li>${item.product} - $${item.price} ARS</li>`;
        total += item.price;
      });
      html += `</ul><p><strong>Total:</strong> $${total} ARS</p>`;
      cartDiv.innerHTML = html;
    }

    function checkout() {
      if (cart.length === 0) {
        alert('Tu carrito está vacío.');
        return;
      }
      window.open("https://mpago.la/16xeeTa", "_blank");
    }
  </script>
</body>
</html>



